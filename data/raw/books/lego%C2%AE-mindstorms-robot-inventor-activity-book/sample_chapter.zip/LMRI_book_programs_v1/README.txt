Source code for the LEGO MINDSTORMS Robot Inventor Activity book by Daniele Benedettelli, No Starch Press 2021
 
Please report errors to danielebenedettelli@gmail.com
Please do not redistribute or resell.